export default {
  define: {
    'process.env.apiUrl': 'http://qa2.cnki.net/sw.api',
    'process.env.apiUrl_help': 'http://kc.cnki.net/fb/api'
  }
};
