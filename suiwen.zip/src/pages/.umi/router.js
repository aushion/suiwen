import React from 'react';
import {
  Router as DefaultRouter,
  Route,
  Switch,
  StaticRouter,
} from 'react-router-dom';
import dynamic from 'umi/dynamic';
import renderRoutes from 'umi/lib/renderRoutes';
import history from '@@/history';
import { routerRedux, dynamic as _dvaDynamic } from 'dva';

const Router = routerRedux.ConnectedRouter;

const routes = [
  {
    path: '/',
    component: __IS_BROWSER
      ? _dvaDynamic({
          component: () =>
            import(/* webpackChunkName: "layouts__index" */ '../../layouts/index.js'),
        })
      : require('../../layouts/index.js').default,
    routes: [
      {
        path: '/help/hotHelp',
        exact: true,
        component: __IS_BROWSER
          ? _dvaDynamic({
              app: require('@tmp/dva').getApp(),
              models: () => [
                import(/* webpackChunkName: 'p__help__model.js' */ 'G:/chenaosheng/suiwen/src/pages/help/model.js').then(
                  m => {
                    return { namespace: 'model', ...m.default };
                  },
                ),
              ],
              component: () =>
                import(/* webpackChunkName: "p__help__hotHelp__index" */ '../help/hotHelp/index.js'),
            })
          : require('../help/hotHelp/index.js').default,
        _title: '知网随问',
        _title_default: '知网随问',
      },
      {
        path: '/help/myHelp',
        exact: true,
        component: __IS_BROWSER
          ? _dvaDynamic({
              app: require('@tmp/dva').getApp(),
              models: () => [
                import(/* webpackChunkName: 'p__help__model.js' */ 'G:/chenaosheng/suiwen/src/pages/help/model.js').then(
                  m => {
                    return { namespace: 'model', ...m.default };
                  },
                ),
              ],
              component: () =>
                import(/* webpackChunkName: "p__help__myHelp__index" */ '../help/myHelp/index.js'),
            })
          : require('../help/myHelp/index.js').default,
        _title: '知网随问',
        _title_default: '知网随问',
      },
      {
        path: '/help/myReply',
        exact: true,
        component: __IS_BROWSER
          ? _dvaDynamic({
              app: require('@tmp/dva').getApp(),
              models: () => [
                import(/* webpackChunkName: 'p__help__model.js' */ 'G:/chenaosheng/suiwen/src/pages/help/model.js').then(
                  m => {
                    return { namespace: 'model', ...m.default };
                  },
                ),
              ],
              component: () =>
                import(/* webpackChunkName: "p__help__myReply__index" */ '../help/myReply/index.js'),
            })
          : require('../help/myReply/index.js').default,
        _title: '知网随问',
        _title_default: '知网随问',
      },
      {
        path: '/help/newHelp',
        exact: true,
        component: __IS_BROWSER
          ? _dvaDynamic({
              app: require('@tmp/dva').getApp(),
              models: () => [
                import(/* webpackChunkName: 'p__help__model.js' */ 'G:/chenaosheng/suiwen/src/pages/help/model.js').then(
                  m => {
                    return { namespace: 'model', ...m.default };
                  },
                ),
              ],
              component: () =>
                import(/* webpackChunkName: "p__help__newHelp__index" */ '../help/newHelp/index.js'),
            })
          : require('../help/newHelp/index.js').default,
        _title: '知网随问',
        _title_default: '知网随问',
      },
      {
        path: '/home',
        exact: true,
        component: __IS_BROWSER
          ? _dvaDynamic({
              app: require('@tmp/dva').getApp(),
              models: () => [
                import(/* webpackChunkName: 'p__home__model.js' */ 'G:/chenaosheng/suiwen/src/pages/home/model.js').then(
                  m => {
                    return { namespace: 'model', ...m.default };
                  },
                ),
              ],
              component: () =>
                import(/* webpackChunkName: "p__home__index" */ '../home/index.js'),
            })
          : require('../home/index.js').default,
        _title: '知网随问',
        _title_default: '知网随问',
      },
      {
        path: '/home/service/home',
        exact: true,
        component: __IS_BROWSER
          ? _dvaDynamic({
              app: require('@tmp/dva').getApp(),
              models: () => [
                import(/* webpackChunkName: 'p__home__model.js' */ 'G:/chenaosheng/suiwen/src/pages/home/model.js').then(
                  m => {
                    return { namespace: 'model', ...m.default };
                  },
                ),
              ],
              component: () =>
                import(/* webpackChunkName: "p__home__service__home" */ '../home/service/home.js'),
            })
          : require('../home/service/home.js').default,
        _title: '知网随问',
        _title_default: '知网随问',
      },
      {
        path: '/',
        exact: true,
        component: __IS_BROWSER
          ? _dvaDynamic({
              component: () =>
                import(/* webpackChunkName: "p__index" */ '../index.js'),
            })
          : require('../index.js').default,
        _title: '知网随问',
        _title_default: '知网随问',
      },
      {
        path: '/reply',
        exact: true,
        component: __IS_BROWSER
          ? _dvaDynamic({
              app: require('@tmp/dva').getApp(),
              models: () => [
                import(/* webpackChunkName: 'p__reply__model.js' */ 'G:/chenaosheng/suiwen/src/pages/reply/model.js').then(
                  m => {
                    return { namespace: 'model', ...m.default };
                  },
                ),
              ],
              component: () =>
                import(/* webpackChunkName: "p__reply__index" */ '../reply/index.js'),
            })
          : require('../reply/index.js').default,
        _title: '知网随问',
        _title_default: '知网随问',
      },
      {
        path: '/result',
        exact: true,
        component: __IS_BROWSER
          ? _dvaDynamic({
              app: require('@tmp/dva').getApp(),
              models: () => [
                import(/* webpackChunkName: 'p__result__model.js' */ 'G:/chenaosheng/suiwen/src/pages/result/model.js').then(
                  m => {
                    return { namespace: 'model', ...m.default };
                  },
                ),
              ],
              component: () =>
                import(/* webpackChunkName: "p__result__index" */ '../result/index.js'),
            })
          : require('../result/index.js').default,
        _title: '知网随问',
        _title_default: '知网随问',
      },
      {
        path: '/result/service/result',
        exact: true,
        component: __IS_BROWSER
          ? _dvaDynamic({
              app: require('@tmp/dva').getApp(),
              models: () => [
                import(/* webpackChunkName: 'p__result__model.js' */ 'G:/chenaosheng/suiwen/src/pages/result/model.js').then(
                  m => {
                    return { namespace: 'model', ...m.default };
                  },
                ),
              ],
              component: () =>
                import(/* webpackChunkName: "p__result__service__result" */ '../result/service/result.js'),
            })
          : require('../result/service/result.js').default,
        _title: '知网随问',
        _title_default: '知网随问',
      },
      {
        component: () =>
          React.createElement(
            require('G:/chenaosheng/suiwen/node_modules/_umi-build-dev@1.16.10@umi-build-dev/lib/plugins/404/NotFound.js')
              .default,
            { pagesPath: 'src/pages', hasRoutesInConfig: false },
          ),
        _title: '知网随问',
        _title_default: '知网随问',
      },
    ],
    _title: '知网随问',
    _title_default: '知网随问',
  },
  {
    component: () =>
      React.createElement(
        require('G:/chenaosheng/suiwen/node_modules/_umi-build-dev@1.16.10@umi-build-dev/lib/plugins/404/NotFound.js')
          .default,
        { pagesPath: 'src/pages', hasRoutesInConfig: false },
      ),
    _title: '知网随问',
    _title_default: '知网随问',
  },
];
window.g_routes = routes;
const plugins = require('umi/_runtimePlugin');
plugins.applyForEach('patchRoutes', { initialValue: routes });

export { routes };

export default class RouterWrapper extends React.Component {
  unListen() {}

  constructor(props) {
    super(props);

    // route change handler
    function routeChangeHandler(location, action) {
      plugins.applyForEach('onRouteChange', {
        initialValue: {
          routes,
          location,
          action,
        },
      });
    }
    this.unListen = history.listen(routeChangeHandler);
    // dva 中 history.listen 会初始执行一次
    // 这里排除掉 dva 的场景，可以避免 onRouteChange 在启用 dva 后的初始加载时被多执行一次
    const isDva =
      history.listen
        .toString()
        .indexOf('callback(history.location, history.action)') > -1;
    if (!isDva) {
      routeChangeHandler(history.location);
    }
  }

  componentWillUnmount() {
    this.unListen();
  }

  render() {
    const props = this.props || {};
    return <Router history={history}>{renderRoutes(routes, props)}</Router>;
  }
}
