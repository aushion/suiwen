const Label = (props) => <span style={{ color: '#3B3F43', fontWeight: 'bold' }}>{props.text}</span>;

export default Label;
