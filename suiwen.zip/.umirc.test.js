export default {
  define: {
    'process.env.apiUrl': 'http://192.168.103.25:8080/sw.api',
    'process.env.apiUrl_help': 'http://192.168.103.24/qa.fb/api'
  }
};
